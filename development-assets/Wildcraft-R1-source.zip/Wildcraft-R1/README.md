# Wildcraft R1 研究交付

R1 研究源码、验证报告与本机证据。游戏安装版仍为 P3 / 0.1.0-dev.4。

项目位于 wildcraft/；研究类只在 src/gametest 中。先阅读 Wildcraft-R1-验证报告.md 与 wildcraft/docs/P3.1-SPEC.md。

源码可按项目 README 使用 JDK 25 与 Gradle 重建。此包不包含 Minecraft、依赖缓存、个人世界、账号信息或已接受的 EULA 文件。
