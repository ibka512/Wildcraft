package dev.wildcraft.client.datagen;

import dev.wildcraft.registry.WildcraftItems;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.minecraft.client.data.models.BlockModelGenerators;
import net.minecraft.client.data.models.ItemModelGenerators;
import net.minecraft.client.data.models.model.ModelTemplates;

public final class WildcraftModelProvider extends FabricModelProvider {
    public WildcraftModelProvider(FabricPackOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(BlockModelGenerators generator) {
        generator.createNonTemplateModelBlock(dev.wildcraft.fabrication.FabricationContent.BLOCK);
        generator.registerSimpleItemModel(dev.wildcraft.fabrication.FabricationContent.BLOCK, net.minecraft.client.data.models.model.ModelLocationUtils.getModelLocation(dev.wildcraft.fabrication.FabricationContent.BLOCK));
        generator.createNonTemplateModelBlock(dev.wildcraft.energy.EnergyContent.CHARGER);
        generator.registerSimpleItemModel(dev.wildcraft.energy.EnergyContent.CHARGER, net.minecraft.client.data.models.model.ModelLocationUtils.getModelLocation(dev.wildcraft.energy.EnergyContent.CHARGER));
        generator.createNonTemplateModelBlock(dev.wildcraft.cooking.CookingContent.POT);
        generator.registerSimpleItemModel(dev.wildcraft.cooking.CookingContent.POT, net.minecraft.client.data.models.model.ModelLocationUtils.getModelLocation(dev.wildcraft.cooking.CookingContent.POT));
    }

    @Override
    public void generateItemModels(ItemModelGenerators generator) {
        generator.generateFlatItem(dev.wildcraft.mechanics.MechanicsContent.BODY, ModelTemplates.FLAT_ITEM);
        generator.generateFlatItem(dev.wildcraft.mechanics.MechanicsContent.FAN, ModelTemplates.FLAT_ITEM);
        for(var part:java.util.List.of(dev.wildcraft.mechanics.MechanicsContent.ROCKET,dev.wildcraft.mechanics.MechanicsContent.SPENT_ROCKET,dev.wildcraft.mechanics.MechanicsContent.SPRING,dev.wildcraft.mechanics.MechanicsContent.STABILIZER,dev.wildcraft.mechanics.MechanicsContent.BUOYANCY))generator.generateFlatItem(part,ModelTemplates.FLAT_ITEM);
        generator.generateFlatItem(dev.wildcraft.mechanics.MechanicsContent.WING, ModelTemplates.FLAT_ITEM);
        generator.generateFlatItem(dev.wildcraft.mechanics.MechanicsContent.WHEEL, ModelTemplates.FLAT_ITEM);
        generator.generateFlatItem(WildcraftItems.TEST_CORE, ModelTemplates.FLAT_ITEM);
        generator.generateFlatItem(WildcraftItems.PARAGLIDER, ModelTemplates.FLAT_ITEM);
    }

    @Override
    public String getName() {
        return "Wildcraft item models";
    }
}
